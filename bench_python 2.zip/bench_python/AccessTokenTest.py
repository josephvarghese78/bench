import msal
import os

# === Configuration ===
def new_token():
    client_id = "72b6fe11-a734-4161-b030-a6c2384e01d6"
    tenant_id = "5d3e2773-e07f-4432-a630-1a0f68a28a05"
    authority = f"https://login.microsoftonline.com/{tenant_id}"
    scopes = ["User.Read"]

    # === Token Cache ===
    cache_file = "token_cache.bin"
    token_cache = msal.SerializableTokenCache()

    if os.path.exists(cache_file):
        token_cache.deserialize(open(cache_file, "r").read())

    app = msal.PublicClientApplication(
        client_id=client_id,
        authority=authority,
        token_cache=token_cache
    )

    # === Try Silent Token First ===
    accounts = app.get_accounts()
    if accounts:
        result = app.acquire_token_silent(scopes, account=accounts[0])
    else:
        result = None

    # === If No Cached Token, Use Device Code Flow ===
    if not result:
        flow = app.initiate_device_flow(scopes=scopes)
        if "user_code" not in flow:
            raise ValueError("Failed to create device flow")
        print(flow["message"])
        result = app.acquire_token_by_device_flow(flow)

    # === Save Cache ===
    if token_cache.has_state_changed:
        with open(cache_file, "w") as f:
            f.write(token_cache.serialize())

    # === Output Token ===
    if "access_token" in result:
        return result["access_token"]
    else:
        print("Error:", result.get("error_description"))
        return None

#a=new_token()
#print(a)