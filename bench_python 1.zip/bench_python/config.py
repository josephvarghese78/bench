valid_status_codes=[200]
error_threshold=5
users=20
runfor=1
user_step=5
think_time=[1,2,3,4,5]
rampup=30
delay_between_thread=1

#active_threads=0
samples_started=0
samples_completed=0

requests_data=None
db_conn=None
db_filename=""
db_cursor=None

project_name=""
suite_id=""
test_name=""
test_start_time=None
error_percent=0
running_users=0
current_errors=0
